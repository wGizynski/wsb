<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles.css">

    <title></title>
</head>

<body>
    <table id="table1">
        <trx>
            <td rowspan="3">1.1</td>
            <td rowspan="2">1.2</td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td rowspan="3">2.2</td>
            </tr>
            <tr>
                <td rowspan="2">3.1;</td>
            </tr>
            <tr>
            </tr>
            <tr>
                <td rowspan="2" colspan="2">4.1;</td>
            </tr>
            <tr>
            </tr>
    </table>
</body>

</html>